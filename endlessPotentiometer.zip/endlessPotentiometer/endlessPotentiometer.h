/*
  endlessPotentiometer.h - Library for using an endless potentiometer
  Specifically the Alpha 14mm Snap-In, Endless Rotary Type, Metal Shaft
  Created by Matt Borland - July 7, 2020
  Released into the public domain.
*/
#ifndef endlessPotentiometer_h
#define endlessPotentiometer_h

#include "Arduino.h"

class endlessPotentiometer
{
  public:
    endlessPotentiometer(int pinA, int pinB);
    double absoluteAngle();
    double totalAngle();
    double relativeChange();
  private:
    int _pinA;
    int _pinB;
    double _currentAngle;
    double _previousAngle;
    double _currentTotalAngle;
    double _previousTotalAngle;
};

#endif
