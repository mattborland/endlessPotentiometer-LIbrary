/*
  endlessPotentiometer.cpp - Library for using an endless potentiometer
  Created by Matt Borland - July 7, 2020
  Released into the public domain.
*/

#include "Arduino.h"
#include "endlessPotentiometer.h"

endlessPotentiometer::endlessPotentiometer(int pinA, int pinB)
{
  pinMode(pinA, INPUT);
  pinMode(pinB, INPUT);
  _pinA = pinA;
  _pinB = pinB;
  _currentAngle = 0;
  _previousAngle = 0;
  _currentTotalAngle = 0;
  _previousTotalAngle = 0;
}

//  return the absolute position of the potentiometer for Analog pin numbers y, x
double endlessPotentiometer::absoluteAngle()
{
  double absoluteAngleVal = atan2(2*(double(analogRead(_pinB))/1023.0-0.5), 2*(double(analogRead(_pinA))/1023.0-0.5));
  return absoluteAngleVal;
}

double endlessPotentiometer::totalAngle()
{
  _currentAngle = absoluteAngle();
  if(abs(_currentAngle)>1.57 and _previousAngle<0 and _currentAngle>=0){
    _currentTotalAngle = _currentTotalAngle-_previousAngle+_currentAngle-TWO_PI;
  } else if(abs(_currentAngle)>1.57 and _previousAngle>=0 and _currentAngle<0){
    _currentTotalAngle = _currentTotalAngle-_previousAngle+_currentAngle+TWO_PI;
  } else {
    _currentTotalAngle = _currentTotalAngle-_previousAngle+_currentAngle;
  }
  _previousAngle = _currentAngle;
  return _currentTotalAngle;
}

double endlessPotentiometer::relativeChange()
{
  totalAngle();
  double relativeChange = _currentTotalAngle-_previousTotalAngle;
  _previousTotalAngle = _currentTotalAngle;
  return relativeChange;
}
